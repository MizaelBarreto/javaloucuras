package  apimizaelesca;
import com.google.gson.Gson;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.URL;

public class APImizaelesca{

    private static final String API_KEY = "QhiRckXbjlszMNEfDd2cfrIdVPvITBbtBZvFKGAm"; 
    private static final String API_URL = "https://api.nasa.gov/planetary/apod?api_key=" + API_KEY;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Astronomy Picture of the Day");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);
            frame.setLayout(new BorderLayout());

           
            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

            
            JLabel welcomeLabel = new JLabel("BEM VINDO A SEU GERADOR DE IMAGENS DIÁRIAS DA NASA", SwingConstants.CENTER);
            welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            welcomeLabel.setFont(new Font("Serif", Font.BOLD, 20));

            
            JLabel imageLabel = new JLabel("Clique no botão para gerar uma imagem", SwingConstants.CENTER);
            imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Adiciona os componentes ao painel principal
            mainPanel.add(welcomeLabel);
            mainPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Espaçamento entre os rótulos
            mainPanel.add(imageLabel);

            // Botão "Gerar Imagem"
            JButton generateButton = new JButton("Gerar Imagem");
            generateButton.setAlignmentX(Component.CENTER_ALIGNMENT);

    
            generateButton.addActionListener(e -> {
                imageLabel.setText("Loading...");
                imageLabel.setIcon(null);
                new Thread(() -> {
                    try {
                        String imageUrl = fetchApodImageUrl();
                        if (imageUrl != null) {
                            ImageIcon imageIcon = new ImageIcon(new URL(imageUrl));
                            imageLabel.setIcon(imageIcon);
                            imageLabel.setText(null); // Remove o texto "Loading..."
                        } else {
                            imageLabel.setText("Failed to load image.");
                        }
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        imageLabel.setText("Error: " + ex.getMessage());
                    }
                }).start();
            });

            frame.add(mainPanel, BorderLayout.CENTER);
            frame.add(generateButton, BorderLayout.SOUTH);

            frame.setVisible(true);
        });
    }

    private static String fetchApodImageUrl() throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(API_URL).build();
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }
            String responseBody = response.body().string();
            Gson gson = new Gson();
            ApodResponse apodResponse = gson.fromJson(responseBody, ApodResponse.class);
            return apodResponse.url;
        }
    }

    static class ApodResponse {

        String url;
    }
}
